import { Link, useNavigate } from "react-router-dom";
import { useDataStore } from "@/store/useAppStore";
import { CheckCircle2, XCircle, Clock, RotateCcw, Home } from "lucide-react";

const OPTION_LABELS = ["A", "B", "C", "D"];

const Results = () => {
  const { sessionResult, setSessionResult } = useDataStore();
  const navigate = useNavigate();

  if (!sessionResult) {
    return (<div className="p-6 max-w-3xl mx-auto text-center"><p className="text-muted-foreground mb-4">No results available.</p><Link to="/subjects" className="text-primary hover:underline">Go to subjects</Link></div>);
  }

  const { subjectName, topicName, total, correct, timeTaken, questionResults, subjectId, topicId } = sessionResult;
  const pct = total > 0 ? Math.round((correct / total) * 100) : 0;
  const minutes = Math.floor(timeTaken / 60);
  const seconds = timeTaken % 60;

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-2">Quiz Results</h1>
      <p className="text-muted-foreground mb-6">{subjectName} › {topicName}</p>
      <div className="glass-card p-8 text-center mb-6">
        <div className={`text-6xl font-bold mb-2 ${pct >= 70 ? "text-success" : pct >= 40 ? "text-warning" : "text-destructive"}`}>{pct}%</div>
        <p className="text-muted-foreground mb-4">{correct} out of {total} correct</p>
        <div className="flex justify-center gap-6 text-sm">
          <span className="flex items-center gap-1.5"><CheckCircle2 size={16} className="text-success" />{correct} correct</span>
          <span className="flex items-center gap-1.5"><XCircle size={16} className="text-destructive" />{total - correct} wrong</span>
          <span className="flex items-center gap-1.5"><Clock size={16} className="text-muted-foreground" />{minutes}m {seconds}s</span>
        </div>
      </div>
      <div className="flex gap-3 mb-8">
        <button onClick={() => { setSessionResult(null); navigate(`/practice/${subjectId}/${topicId}`); }}
          className="flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition-all text-sm">
          <RotateCcw size={16} /> Retry
        </button>
        <Link to="/" className="flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-secondary text-secondary-foreground font-medium hover:bg-muted transition-colors text-sm">
          <Home size={16} /> Home
        </Link>
      </div>
      <h2 className="text-lg font-semibold mb-4">Review</h2>
      <div className="space-y-3">
        {questionResults.map((qr, i) => (
          <div key={i} className={`glass-card p-4 border-l-4 ${qr.correct ? "border-l-success" : "border-l-destructive"}`}>
            <p className="text-sm font-medium mb-2">{i + 1}. {qr.question.question}</p>
            <div className="text-xs text-muted-foreground space-y-0.5">
              <p>Your answer: <span className={qr.correct ? "text-success" : "text-destructive"}>{qr.selectedIndex >= 0 ? `${OPTION_LABELS[qr.selectedIndex]}. ${qr.question.options[qr.selectedIndex]}` : "Not answered"}</span></p>
              {!qr.correct && <p>Correct: <span className="text-success">{OPTION_LABELS[qr.question.answerIndex]}. {qr.question.options[qr.question.answerIndex]}</span></p>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Results;
