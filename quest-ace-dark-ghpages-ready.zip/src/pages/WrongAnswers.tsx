import { useMemo } from "react";
import { Link } from "react-router-dom";
import { XCircle } from "lucide-react";
import { useDataStore, useProgressStore } from "@/store/useAppStore";
import { Breadcrumbs } from "@/components/Breadcrumbs";
import { Question } from "@/types/question";

const OPTION_LABELS = ["A", "B", "C", "D"];

const WrongAnswers = () => {
  const { questionsBySubjectTopic } = useDataStore();
  const { answers } = useProgressStore();

  const wrongQuestions = useMemo(() => {
    const all: Question[] = [];
    for (const topics of Object.values(questionsBySubjectTopic)) {
      for (const questions of Object.values(topics)) all.push(...questions);
    }
    return all.filter((q) => answers[q.id] && !answers[q.id].correct);
  }, [questionsBySubjectTopic, answers]);

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <Breadcrumbs items={[{ label: "Home", to: "/" }, { label: "Wrong Answers" }]} />
      <div className="flex items-center gap-3 mb-6">
        <XCircle size={24} className="text-destructive" />
        <h1 className="text-2xl font-bold">Wrong Answers</h1>
        <span className="text-sm text-muted-foreground">({wrongQuestions.length})</span>
      </div>
      {wrongQuestions.length === 0 ? (
        <div className="glass-card p-12 text-center">
          <XCircle size={48} className="mx-auto text-muted-foreground/30 mb-4" />
          <p className="text-muted-foreground">No wrong answers yet. Keep practicing!</p>
          <Link to="/subjects" className="text-primary text-sm hover:underline mt-2 inline-block">Start practicing</Link>
        </div>
      ) : (
        <div className="space-y-3">
          {wrongQuestions.map((q) => {
            const userAnswer = answers[q.id];
            return (
              <div key={q.id} className="glass-card p-4 border-l-4 border-l-destructive">
                <p className="text-xs text-muted-foreground mb-1">{q.subjectName} › {q.topicName}</p>
                <p className="text-sm font-medium mb-2">{q.question}</p>
                <div className="text-xs space-y-0.5">
                  <p className="text-destructive">Your answer: {OPTION_LABELS[userAnswer.selectedIndex]}. {q.options[userAnswer.selectedIndex]}</p>
                  <p className="text-success">Correct: {OPTION_LABELS[q.answerIndex]}. {q.options[q.answerIndex]}</p>
                </div>
                <Link to={`/practice/${q.subjectId}/${q.topicId}`} className="text-primary text-xs hover:underline mt-2 inline-block">Practice this topic →</Link>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default WrongAnswers;
