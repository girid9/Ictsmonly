import { useMemo } from "react";
import { Link } from "react-router-dom";
import { BookOpen, ArrowRight } from "lucide-react";
import { useDataStore, useProgressStore } from "@/store/useAppStore";
import { Breadcrumbs } from "@/components/Breadcrumbs";

const SUBJECT_COLORS = ["from-primary/20 to-primary/5", "from-success/20 to-success/5", "from-warning/20 to-warning/5", "from-destructive/20 to-destructive/5"];

const Subjects = () => {
  const { subjects, questionsBySubjectTopic } = useDataStore();
  const { answers } = useProgressStore();

  const subjectsWithProgress = useMemo(() => {
    return subjects.map((s) => {
      const allQs = Object.values(questionsBySubjectTopic[s.id] || {}).flat();
      const answered = allQs.filter((q) => answers[q.id]).length;
      const correct = allQs.filter((q) => answers[q.id]?.correct).length;
      const pct = answered > 0 ? Math.round((correct / answered) * 100) : 0;
      return { ...s, answered, correct, pct };
    });
  }, [subjects, answers, questionsBySubjectTopic]);

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <Breadcrumbs items={[{ label: "Home", to: "/" }, { label: "Subjects" }]} />
      <h1 className="text-2xl font-bold mb-6">All Subjects</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {subjectsWithProgress.map((s, i) => (
          <Link key={s.id} to={`/subjects/${s.id}`} className="glass-card overflow-hidden hover:border-primary/40 transition-all group">
            <div className={`h-2 bg-gradient-to-r ${SUBJECT_COLORS[i % SUBJECT_COLORS.length]}`} />
            <div className="p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center"><BookOpen size={20} className="text-primary" /></div>
                <ArrowRight size={18} className="text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all mt-1" />
              </div>
              <h2 className="font-semibold mb-1">{s.name}</h2>
              <p className="text-sm text-muted-foreground">{s.topicCount} topics · {s.questionCount} questions</p>
              {s.answered > 0 && (
                <div className="mt-3">
                  <div className="flex justify-between text-xs text-muted-foreground mb-1">
                    <span>{s.answered}/{s.questionCount} answered</span>
                    <span>{s.pct}% accuracy</span>
                  </div>
                  <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
                    <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${(s.answered / s.questionCount) * 100}%` }} />
                  </div>
                </div>
              )}
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default Subjects;
