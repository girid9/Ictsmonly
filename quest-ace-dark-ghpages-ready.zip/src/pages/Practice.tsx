import { useState, useEffect, useMemo, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Bookmark, BookmarkCheck, ChevronLeft, ChevronRight } from "lucide-react";
import { useDataStore, useProgressStore } from "@/store/useAppStore";
import { Breadcrumbs } from "@/components/Breadcrumbs";
import { McqProgressBar } from "@/components/McqProgressBar";
import { shuffle } from "@/utils/shuffle";
import { Question } from "@/types/question";

const OPTION_LABELS = ["A", "B", "C", "D"];

const Practice = () => {
  const { subjectId, topicId } = useParams<{ subjectId: string; topicId: string }>();
  const navigate = useNavigate();
  const { subjects, questionsBySubjectTopic } = useDataStore();
  const { bookmarkedIds, recordAnswer, toggleBookmark, setLastVisited } = useProgressStore();
  const setSessionResult = useDataStore((s) => s.setSessionResult);

  const rawQuestions = useMemo(() => {
    if (!subjectId || !topicId) return [];
    return questionsBySubjectTopic[subjectId]?.[topicId] ?? [];
  }, [subjectId, topicId, questionsBySubjectTopic]);

  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [revealed, setRevealed] = useState(false);
  const [sessionAnswers, setSessionAnswers] = useState<Record<number, { selected: number; correct: boolean }>>({});
  const [startTime] = useState(Date.now());

  useEffect(() => {
    if (rawQuestions.length > 0) setQuestions(shuffle(rawQuestions));
  }, [rawQuestions]);

  useEffect(() => {
    if (rawQuestions.length > 0 && subjectId && topicId) {
      const subject = subjects.find((s) => s.id === subjectId);
      setLastVisited({ subjectId, topicId, subjectName: subject?.name || subjectId, topicName: rawQuestions[0]?.topicName || topicId });
    }
  }, [rawQuestions, subjectId, topicId, subjects, setLastVisited]);

  const currentQuestion = questions[currentIndex];
  const isBookmarked = currentQuestion ? bookmarkedIds.includes(currentQuestion.id) : false;

  const handleSelect = useCallback((optionIndex: number) => {
    if (revealed || !currentQuestion) return;
    const correct = optionIndex === currentQuestion.answerIndex;
    setSelectedOption(optionIndex);
    setRevealed(true);
    setSessionAnswers((prev) => ({ ...prev, [currentIndex]: { selected: optionIndex, correct } }));
    recordAnswer(currentQuestion.id, optionIndex, correct);
  }, [revealed, currentQuestion, currentIndex, recordAnswer]);

  const handleNext = useCallback(() => {
    if (currentIndex < questions.length - 1) {
      const nextIdx = currentIndex + 1;
      setCurrentIndex(nextIdx);
      const prev = sessionAnswers[nextIdx];
      if (prev) { setSelectedOption(prev.selected); setRevealed(true); } else { setSelectedOption(null); setRevealed(false); }
    } else {
      const allAnswers = { ...sessionAnswers };
      if (selectedOption !== null && currentQuestion) {
        allAnswers[currentIndex] = { selected: selectedOption, correct: selectedOption === currentQuestion.answerIndex };
      }
      const correct = Object.values(allAnswers).filter((a) => a.correct).length;
      setSessionResult({
        subjectName: currentQuestion?.subjectName || "", topicName: currentQuestion?.topicName || "",
        subjectId: subjectId || "", topicId: topicId || "",
        total: questions.length, correct, timeTaken: Math.round((Date.now() - startTime) / 1000),
        questionResults: questions.map((q, i) => ({ question: q, selectedIndex: allAnswers[i]?.selected ?? -1, correct: allAnswers[i]?.correct ?? false })),
      });
      navigate("/results");
    }
  }, [currentIndex, questions, sessionAnswers, selectedOption, currentQuestion, subjectId, topicId, startTime, navigate, setSessionResult]);

  const handlePrev = useCallback(() => {
    if (currentIndex > 0) {
      const prevIdx = currentIndex - 1;
      setCurrentIndex(prevIdx);
      const prev = sessionAnswers[prevIdx];
      if (prev) { setSelectedOption(prev.selected); setRevealed(true); } else { setSelectedOption(null); setRevealed(false); }
    }
  }, [currentIndex, sessionAnswers]);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (target.tagName === "INPUT" || target.tagName === "TEXTAREA") return;
      if (e.key >= "1" && e.key <= "4") handleSelect(parseInt(e.key) - 1);
      else if (e.key.toLowerCase() === "n" && revealed) handleNext();
      else if (e.key.toLowerCase() === "p") handlePrev();
      else if (e.key.toLowerCase() === "b" && currentQuestion) toggleBookmark(currentQuestion.id);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [handleSelect, handleNext, handlePrev, currentQuestion, toggleBookmark, revealed]);

  if (questions.length === 0) return <div className="p-6 max-w-3xl mx-auto text-center"><p className="text-muted-foreground">No questions available.</p></div>;
  if (!currentQuestion) return null;

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <Breadcrumbs items={[{ label: "Subjects", to: "/subjects" }, { label: currentQuestion.subjectName, to: `/subjects/${subjectId}` }, { label: currentQuestion.topicName }]} />
      <div className="flex items-center justify-between mb-4">
        <span className="text-sm text-muted-foreground">Question {currentIndex + 1} of {questions.length}</span>
        <button onClick={() => toggleBookmark(currentQuestion.id)} className="p-2 rounded-lg hover:bg-secondary transition-colors" title="Bookmark">
          {isBookmarked ? <BookmarkCheck size={20} className="text-primary" /> : <Bookmark size={20} className="text-muted-foreground" />}
        </button>
      </div>
      <McqProgressBar current={currentIndex + 1} total={questions.length} />
      <div className="glass-card p-6 mt-6">
        <h2 className="text-lg font-medium leading-relaxed mb-6">{currentQuestion.question}</h2>
        <div className="space-y-3">
          {currentQuestion.options.map((option, i) => {
            if (!option.trim()) return null;
            let extraClass = "";
            if (revealed) {
              if (i === currentQuestion.answerIndex) extraClass = "option-btn-correct";
              else if (i === selectedOption) extraClass = "option-btn-wrong";
              else extraClass = "option-btn-disabled";
            }
            return (
              <button key={i} onClick={() => handleSelect(i)} disabled={revealed} className={`option-btn ${extraClass}`}>
                <span className="h-8 w-8 rounded-lg bg-muted flex items-center justify-center text-sm font-bold shrink-0">{OPTION_LABELS[i]}</span>
                <span className="text-sm">{option}</span>
              </button>
            );
          })}
        </div>
        {revealed && currentQuestion.notes && (
          <div className="mt-6 p-4 bg-secondary/50 rounded-xl border border-border">
            <p className="text-xs font-semibold text-primary uppercase tracking-wider mb-1">Explanation</p>
            <p className="text-sm text-muted-foreground leading-relaxed">{currentQuestion.notes}</p>
          </div>
        )}
        {revealed && !currentQuestion.notes && (
          <div className="mt-6 p-4 bg-secondary/50 rounded-xl border border-border">
            <p className="text-sm text-muted-foreground">
              {selectedOption === currentQuestion.answerIndex ? "✅ Correct!" : `❌ Incorrect. The correct answer is ${OPTION_LABELS[currentQuestion.answerIndex]}.`}
            </p>
          </div>
        )}
      </div>
      <div className="flex justify-between items-center mt-6">
        <button onClick={handlePrev} disabled={currentIndex === 0} className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-secondary hover:bg-muted transition-colors disabled:opacity-40 disabled:cursor-not-allowed text-sm font-medium">
          <ChevronLeft size={16} /> Previous
        </button>
        <button onClick={handleNext} disabled={!revealed} className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-primary text-primary-foreground hover:opacity-90 transition-all disabled:opacity-40 disabled:cursor-not-allowed text-sm font-medium">
          {currentIndex === questions.length - 1 ? "Finish" : "Next"} <ChevronRight size={16} />
        </button>
      </div>
      <p className="text-center text-xs text-muted-foreground mt-4">Keys: 1-4 answer · N next · P prev · B bookmark</p>
    </div>
  );
};

export default Practice;
