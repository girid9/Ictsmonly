import { useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { BookOpen, Swords, ArrowRight, Target, TrendingUp, Search } from "lucide-react";
import { useDataStore, useProgressStore } from "@/store/useAppStore";
import { search } from "@/services/questionBank";

const Home = () => {
  const { subjects, questionsBySubjectTopic } = useDataStore();
  const { answers, bookmarkedIds, lastVisited } = useProgressStore();
  const navigate = useNavigate();
  const [query, setQuery] = useState("");

  const stats = useMemo(() => {
    const total = Object.values(questionsBySubjectTopic).reduce(
      (acc, topics) => acc + Object.values(topics).reduce((a, qs) => a + qs.length, 0), 0
    );
    const answered = Object.keys(answers).length;
    const correct = Object.values(answers).filter((a) => a.correct).length;
    const accuracy = answered > 0 ? Math.round((correct / answered) * 100) : 0;
    return { total, answered, correct, accuracy, bookmarks: bookmarkedIds.length };
  }, [questionsBySubjectTopic, answers, bookmarkedIds]);

  const searchResults = useMemo(() => {
    if (!query.trim()) return [];
    return search(query);
  }, [query]);

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Welcome to <span className="text-primary">MCQ Practice</span></h1>
        <p className="text-muted-foreground">Master your subjects with interactive quizzes</p>
      </div>
      <div className="relative mb-8">
        <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
        <input type="text" placeholder="Search questions, topics, or subjects..." value={query} onChange={(e) => setQuery(e.target.value)}
          className="w-full pl-11 pr-4 py-3 bg-card border border-border rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all" />
        {searchResults.length > 0 && (
          <div className="absolute top-full mt-2 left-0 right-0 bg-card border border-border rounded-xl shadow-xl max-h-80 overflow-y-auto z-50">
            {searchResults.slice(0, 10).map((q) => (
              <button key={q.id} onClick={() => { navigate(`/practice/${q.subjectId}/${q.topicId}`); setQuery(""); }}
                className="w-full text-left px-4 py-3 hover:bg-secondary/50 transition-colors border-b border-border last:border-0">
                <p className="text-sm font-medium truncate">{q.question}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{q.subjectName} › {q.topicName}</p>
              </button>
            ))}
          </div>
        )}
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-8">
        {[
          { label: "Total Questions", value: stats.total, icon: BookOpen },
          { label: "Answered", value: stats.answered, icon: Target },
          { label: "Accuracy", value: `${stats.accuracy}%`, icon: TrendingUp },
          { label: "Bookmarks", value: stats.bookmarks, icon: BookOpen },
        ].map(({ label, value, icon: Icon }) => (
          <div key={label} className="glass-card p-4 flex flex-col items-center gap-2">
            <Icon size={20} className="text-primary" />
            <span className="text-2xl font-bold">{value}</span>
            <span className="text-xs text-muted-foreground">{label}</span>
          </div>
        ))}
      </div>
      {lastVisited && (
        <Link to={`/practice/${lastVisited.subjectId}/${lastVisited.topicId}`}
          className="glass-card p-5 mb-8 flex items-center justify-between hover:border-primary/40 transition-all group block">
          <div>
            <p className="text-xs text-primary font-medium uppercase tracking-wider mb-1">Continue where you left off</p>
            <p className="font-semibold">{lastVisited.topicName}</p>
            <p className="text-sm text-muted-foreground">{lastVisited.subjectName}</p>
          </div>
          <ArrowRight size={20} className="text-primary group-hover:translate-x-1 transition-transform" />
        </Link>
      )}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Link to="/subjects" className="glass-card p-6 flex items-center gap-4 hover:border-primary/40 transition-all group">
          <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center"><BookOpen size={24} className="text-primary" /></div>
          <div><h3 className="font-semibold">Start Practice</h3><p className="text-sm text-muted-foreground">{subjects.length} subjects available</p></div>
          <ArrowRight size={18} className="ml-auto text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
        </Link>
        <Link to="/battle" className="glass-card p-6 flex items-center gap-4 hover:border-primary/40 transition-all group">
          <div className="h-12 w-12 rounded-xl bg-warning/10 flex items-center justify-center"><Swords size={24} className="text-warning" /></div>
          <div><h3 className="font-semibold">Battle Mode</h3><p className="text-sm text-muted-foreground">Challenge a friend</p></div>
          <ArrowRight size={18} className="ml-auto text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
        </Link>
      </div>
    </div>
  );
};

export default Home;
