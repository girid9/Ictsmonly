import { useMemo } from "react";
import { Link } from "react-router-dom";
import { Bookmark, BookmarkX } from "lucide-react";
import { useDataStore, useProgressStore } from "@/store/useAppStore";
import { Breadcrumbs } from "@/components/Breadcrumbs";
import { Question } from "@/types/question";

const OPTION_LABELS = ["A", "B", "C", "D"];

const Bookmarks = () => {
  const { questionsBySubjectTopic } = useDataStore();
  const { bookmarkedIds, toggleBookmark } = useProgressStore();

  const bookmarkedQuestions = useMemo(() => {
    const all: Question[] = [];
    for (const topics of Object.values(questionsBySubjectTopic)) {
      for (const questions of Object.values(topics)) all.push(...questions);
    }
    return all.filter((q) => bookmarkedIds.includes(q.id));
  }, [questionsBySubjectTopic, bookmarkedIds]);

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <Breadcrumbs items={[{ label: "Home", to: "/" }, { label: "Bookmarks" }]} />
      <div className="flex items-center gap-3 mb-6">
        <Bookmark size={24} className="text-primary" />
        <h1 className="text-2xl font-bold">Bookmarks</h1>
        <span className="text-sm text-muted-foreground">({bookmarkedQuestions.length})</span>
      </div>
      {bookmarkedQuestions.length === 0 ? (
        <div className="glass-card p-12 text-center">
          <Bookmark size={48} className="mx-auto text-muted-foreground/30 mb-4" />
          <p className="text-muted-foreground">No bookmarked questions yet.</p>
          <Link to="/subjects" className="text-primary text-sm hover:underline mt-2 inline-block">Start practicing</Link>
        </div>
      ) : (
        <div className="space-y-3">
          {bookmarkedQuestions.map((q) => (
            <div key={q.id} className="glass-card p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-muted-foreground mb-1">{q.subjectName} › {q.topicName}</p>
                  <p className="text-sm font-medium mb-2">{q.question}</p>
                  <p className="text-xs text-success">Answer: {OPTION_LABELS[q.answerIndex]}. {q.options[q.answerIndex]}</p>
                </div>
                <button onClick={() => toggleBookmark(q.id)} className="p-2 rounded-lg hover:bg-secondary transition-colors shrink-0" title="Remove bookmark">
                  <BookmarkX size={16} className="text-destructive" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Bookmarks;
