import { useEffect, useState } from "react";
import { Outlet, useLocation } from "react-router-dom";
import { AppSidebar } from "./AppSidebar";
import { Menu } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useDataStore } from "@/store/useAppStore";
import { loadAll } from "@/services/questionBank";

export function Layout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();
  const setData = useDataStore((s) => s.setData);
  const loaded = useDataStore((s) => s.loaded);

  useEffect(() => {
    let cancelled = false;
    loadAll().then((data) => {
      if (!cancelled) setData(data);
    }).catch((e) => console.error("Failed to load data:", e));
    return () => { cancelled = true; };
  }, []); // eslint-disable-line

  useEffect(() => {
    window.scrollTo(0, 0);
    setSidebarOpen(false);
  }, [location.pathname]);

  if (!loaded) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="flex flex-col items-center gap-4">
          <div className="h-10 w-10 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          <p className="text-muted-foreground text-sm">Loading questions...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen">
      {sidebarOpen && (
        <div className="fixed inset-0 bg-background/60 backdrop-blur-sm z-30 md:hidden" onClick={() => setSidebarOpen(false)} />
      )}
      <aside className={`fixed md:sticky top-0 left-0 h-screen z-40 transition-transform duration-300 ease-out ${sidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"}`}>
        <AppSidebar onClose={() => setSidebarOpen(false)} />
      </aside>
      <div className="flex-1 flex flex-col min-h-screen w-full">
        <header className="sticky top-0 z-20 h-14 flex items-center px-4 border-b border-border bg-background/80 backdrop-blur-md">
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-2 rounded-lg hover:bg-secondary transition-colors md:hidden">
            <Menu size={20} />
          </button>
          <span className="ml-2 font-bold text-sm tracking-wide text-primary">📝 MCQ Practice</span>
        </header>
        <main className="flex-1">
          <AnimatePresence mode="wait">
            <motion.div key={location.pathname} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.2, ease: "easeOut" }}>
              <Outlet />
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}
