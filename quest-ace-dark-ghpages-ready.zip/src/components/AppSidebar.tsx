import { NavLink } from "react-router-dom";
import {
  Home,
  BookOpen,
  Bookmark,
  XCircle,
  Swords,
  X,
} from "lucide-react";

const links = [
  { to: "/", icon: Home, label: "Home" },
  { to: "/subjects", icon: BookOpen, label: "Subjects" },
  { to: "/bookmarks", icon: Bookmark, label: "Bookmarks" },
  { to: "/wrong", icon: XCircle, label: "Wrong Answers" },
  { to: "/battle", icon: Swords, label: "Battle" },
];

interface Props {
  onClose: () => void;
}

export function AppSidebar({ onClose }: Props) {
  return (
    <div className="w-60 h-full bg-sidebar flex flex-col border-r border-sidebar-border">
      <div className="h-14 flex items-center justify-between px-4 border-b border-sidebar-border">
        <span className="font-bold text-lg text-primary">📝 MCQ</span>
        <button
          onClick={onClose}
          className="md:hidden p-1.5 rounded-lg hover:bg-sidebar-accent transition-colors"
        >
          <X size={18} />
        </button>
      </div>

      <nav className="flex-1 p-3 space-y-1">
        {links.map(({ to, icon: Icon, label }) => (
          <NavLink
            key={to}
            to={to}
            end={to === "/"}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 ${
                isActive
                  ? "bg-sidebar-accent text-primary shadow-sm"
                  : "text-sidebar-foreground hover:bg-sidebar-accent/60 hover:text-foreground"
              }`
            }
          >
            <Icon size={18} />
            {label}
          </NavLink>
        ))}
      </nav>

      <div className="p-4 border-t border-sidebar-border">
        <p className="text-xs text-muted-foreground text-center">
          Offline MCQ App
        </p>
      </div>
    </div>
  );
}
