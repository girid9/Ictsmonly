import { useState, useEffect, useMemo, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Bookmark, BookmarkCheck, ChevronLeft, ChevronRight, Settings } from "lucide-react";
import { useDataStore, useProgressStore } from "@/store/useAppStore";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

import { Breadcrumbs } from "@/components/Breadcrumbs";
import { McqProgressBar } from "@/components/McqProgressBar";
import { shuffle } from "@/utils/shuffle";
import { Question } from "@/types/question";

const OPTION_LABELS = ["A", "B", "C", "D"];

const Practice = () => {
  const { subjectId, topicId } = useParams<{ subjectId: string; topicId: string }>();
  const navigate = useNavigate();
  const { subjects, questionsBySubjectTopic } = useDataStore();
  const { bookmarkedIds, recordAnswer, toggleBookmark, setLastVisited, settings, updateSettings } = useProgressStore();
  const setSessionResult = useDataStore((s) => s.setSessionResult);

  const rawQuestions = useMemo(() => {
    if (!subjectId || !topicId) return [];
    return questionsBySubjectTopic[subjectId]?.[topicId] ?? [];
  }, [subjectId, topicId, questionsBySubjectTopic]);

  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [revealed, setRevealed] = useState(false);
  const [sessionAnswers, setSessionAnswers] = useState<Record<number, { selected: number; correct: boolean }>>({});
  const [startTime] = useState(Date.now());

  useEffect(() => {
    if (rawQuestions.length > 0) setQuestions(shuffle(rawQuestions));
  }, [rawQuestions]);

  useEffect(() => {
    if (rawQuestions.length > 0 && subjectId && topicId) {
      const subject = subjects.find((s) => s.id === subjectId);
      setLastVisited({ subjectId, topicId, subjectName: subject?.name || subjectId, topicName: rawQuestions[0]?.topicName || topicId });
    }
  }, [rawQuestions, subjectId, topicId, subjects, setLastVisited]);

  const currentQuestion = questions[currentIndex];
  const isBookmarked = currentQuestion ? bookmarkedIds.includes(currentQuestion.id) : false;

  const handleSelect = useCallback((optionIndex: number) => {
    if (revealed || !currentQuestion) return;
    const correct = optionIndex === currentQuestion.answerIndex;
    setSelectedOption(optionIndex);
    setRevealed(true);
    setSessionAnswers((prev) => ({ ...prev, [currentIndex]: { selected: optionIndex, correct } }));
    recordAnswer(currentQuestion.id, optionIndex, correct);
  }, [revealed, currentQuestion, currentIndex, recordAnswer]);

  const handleNext = useCallback(() => {
    if (currentIndex < questions.length - 1) {
      const nextIdx = currentIndex + 1;
      setCurrentIndex(nextIdx);
      const prev = sessionAnswers[nextIdx];
      if (prev) { setSelectedOption(prev.selected); setRevealed(true); } else { setSelectedOption(null); setRevealed(false); }
    } else {
      const allAnswers = { ...sessionAnswers };
      if (selectedOption !== null && currentQuestion) {
        allAnswers[currentIndex] = { selected: selectedOption, correct: selectedOption === currentQuestion.answerIndex };
      }
      const correct = Object.values(allAnswers).filter((a) => a.correct).length;
      setSessionResult({
        subjectName: currentQuestion?.subjectName || "", topicName: currentQuestion?.topicName || "",
        subjectId: subjectId || "", topicId: topicId || "",
        total: questions.length, correct, timeTaken: Math.round((Date.now() - startTime) / 1000),
        questionResults: questions.map((q, i) => ({ question: q, selectedIndex: allAnswers[i]?.selected ?? -1, correct: allAnswers[i]?.correct ?? false })),
      });
      navigate("/results");
    }
  }, [currentIndex, questions, sessionAnswers, selectedOption, currentQuestion, subjectId, topicId, startTime, navigate, setSessionResult]);

  const handlePrev = useCallback(() => {
    if (currentIndex > 0) {
      const prevIdx = currentIndex - 1;
      setCurrentIndex(prevIdx);
      const prev = sessionAnswers[prevIdx];
      if (prev) { setSelectedOption(prev.selected); setRevealed(true); } else { setSelectedOption(null); setRevealed(false); }
    }
  }, [currentIndex, sessionAnswers]);

  useEffect(() => {
    if (revealed && settings.autoAdvance && currentIndex < questions.length - 1) {
      const timer = setTimeout(() => {
        handleNext();
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [revealed, settings.autoAdvance, currentIndex, questions.length, handleNext]);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (target.tagName === "INPUT" || target.tagName === "TEXTAREA") return;
      if (e.key >= "1" && e.key <= "4") handleSelect(parseInt(e.key) - 1);
      else if (e.key.toLowerCase() === "n" && revealed) handleNext();
      else if (e.key.toLowerCase() === "p") handlePrev();
      else if (e.key.toLowerCase() === "b" && currentQuestion) toggleBookmark(currentQuestion.id);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [handleSelect, handleNext, handlePrev, currentQuestion, toggleBookmark, revealed]);

  if (questions.length === 0) return <div className="p-6 max-w-3xl mx-auto text-center"><p className="text-muted-foreground">No questions available.</p></div>;
  if (!currentQuestion) return null;

  return (
    <div className="p-4 md:p-10 max-w-4xl mx-auto h-screen flex flex-col overflow-hidden">
      <div className="flex items-center justify-between gap-4 mb-4 md:mb-10 shrink-0">
        <div className="hidden md:block">
          <Breadcrumbs items={[{ label: "Subjects", to: "/subjects" }, { label: currentQuestion.subjectName, to: `/subjects/${subjectId}` }, { label: currentQuestion.topicName }]} />
          <h1 className="text-3xl font-black mt-2 tracking-tighter uppercase">Practice</h1>
        </div>
        <div className="md:hidden">
          <h1 className="text-xl font-black tracking-tighter uppercase text-primary">QUEST ACE</h1>
        </div>
        <div className="flex items-center gap-3">
          <Popover>
            <PopoverTrigger asChild>
              <button className="h-12 w-12 rounded-2xl bg-white/40 dark:bg-white/5 border border-white/40 dark:border-white/10 flex items-center justify-center hover:bg-white/60 dark:hover:bg-white/10 transition-all text-muted-foreground shadow-sm" title="Settings">
                <Settings size={22} />
              </button>
            </PopoverTrigger>
            <PopoverContent className="w-72 rounded-[2rem] border-white/20 bg-white/80 dark:bg-black/80 backdrop-blur-2xl p-8 shadow-2xl">
              <div className="space-y-6">
                <h4 className="font-black uppercase tracking-[0.2em] text-[10px] text-muted-foreground">Settings</h4>
                <div className="flex items-center justify-between">
                  <Label htmlFor="auto-advance" className="text-sm font-black">Auto-advance (1.5s)</Label>
                  <Switch
                    id="auto-advance"
                    checked={settings.autoAdvance}
                    onCheckedChange={(checked) => updateSettings({ autoAdvance: checked })}
                  />
                </div>
              </div>
            </PopoverContent>
          </Popover>
          <button onClick={() => toggleBookmark(currentQuestion.id)} className="h-12 w-12 rounded-2xl bg-white/40 dark:bg-white/5 border border-white/40 dark:border-white/10 flex items-center justify-center hover:bg-white/60 dark:hover:bg-white/10 transition-all shadow-sm" title="Bookmark">
            {isBookmarked ? <BookmarkCheck size={22} className="text-primary" /> : <Bookmark size={22} className="text-muted-foreground" />}
          </button>
        </div>
      </div>

      <div className="mb-6 md:mb-10 shrink-0">
        <div className="flex items-center justify-between mb-3">
          <span className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground">Overall Progress</span>
          <span className="text-[10px] font-black uppercase tracking-[0.2em] text-primary">{Math.round(((currentIndex + 1) / questions.length) * 100)}%</span>
        </div>
        <McqProgressBar current={currentIndex + 1} total={questions.length} />
      </div>

      <div className="glass-card p-6 md:p-12 flex-1 overflow-y-auto min-h-0 custom-scrollbar">
        <div className="flex items-center gap-3 mb-6 md:mb-8">
          <div className="h-2.5 w-2.5 rounded-full bg-primary animate-pulse" />
          <span className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground">Question {currentIndex + 1} of {questions.length}</span>
        </div>
        <h2 className="text-xl md:text-3xl font-black leading-tight mb-8 md:mb-12 text-foreground">{currentQuestion.question}</h2>
        <div className="grid grid-cols-1 gap-3 md:gap-5">
          {currentQuestion.options.map((option, i) => {
            if (!option.trim()) return null;
            let extraClass = "";
            if (revealed) {
              if (i === currentQuestion.answerIndex) extraClass = "option-btn-correct";
              else if (i === selectedOption) extraClass = "option-btn-wrong";
              else extraClass = "option-btn-disabled";
            }
            return (
              <button key={i} onClick={() => handleSelect(i)} disabled={revealed} className={`option-btn ${extraClass}`}>
                <span className="h-8 w-8 rounded-lg bg-muted flex items-center justify-center text-sm font-bold shrink-0">{OPTION_LABELS[i]}</span>
                <span className="text-sm">{option}</span>
              </button>
            );
          })}
        </div>
        {revealed && currentQuestion.notes && (
          <div className={`mt-4 md:mt-6 p-4 md:p-5 rounded-xl border-l-4 ${selectedOption === currentQuestion.answerIndex ? 'bg-success/5 border-success' : 'bg-destructive/5 border-destructive'} animate-in fade-in slide-in-from-top-2 duration-300`}>
            <div className="flex items-center justify-between mb-2 md:mb-3">
              <div className="flex items-center gap-2">
                <div className={`h-1.5 w-1.5 rounded-full ${selectedOption === currentQuestion.answerIndex ? 'bg-success' : 'bg-destructive'} animate-pulse`} />
                <p className={`text-[10px] md:text-xs font-bold uppercase tracking-widest ${selectedOption === currentQuestion.answerIndex ? 'text-success' : 'text-destructive'}`}>
                  {selectedOption === currentQuestion.answerIndex ? 'Correct' : 'Incorrect'}
                </p>
              </div>
              <div className="px-1.5 py-0.5 rounded bg-primary/10 text-[9px] font-bold text-primary uppercase tracking-tighter">Explanation</div>
            </div>
            <p className="text-xs md:text-sm text-foreground/90 leading-relaxed font-medium">
              {currentQuestion.notes}
            </p>
          </div>
        )}
        {revealed && !currentQuestion.notes && (
          <div className="mt-6 p-4 bg-secondary/50 rounded-xl border border-border">
            <p className="text-sm text-muted-foreground">
              {selectedOption === currentQuestion.answerIndex ? "✅ Correct!" : `❌ Incorrect. The correct answer is ${OPTION_LABELS[currentQuestion.answerIndex]}.`}
            </p>
          </div>
        )}
      </div>
      <div className="flex justify-between items-center mt-6 md:mt-12 gap-4 shrink-0 pb-4">
        <button onClick={handlePrev} disabled={currentIndex === 0} className="flex-1 md:flex-none flex items-center justify-center gap-3 px-6 md:px-10 py-4 md:py-5 rounded-[1.5rem] bg-white/40 dark:bg-white/5 border border-white/40 dark:border-white/10 hover:bg-white/60 dark:hover:bg-white/10 transition-all disabled:opacity-20 disabled:cursor-not-allowed text-[10px] md:text-xs font-black uppercase tracking-[0.2em]">
          <ChevronLeft size={18} /> Prev
        </button>
        <button onClick={handleNext} disabled={!revealed} className="flex-1 md:flex-none flex items-center justify-center gap-3 px-8 md:px-12 py-4 md:py-5 rounded-[1.5rem] bg-primary text-white hover:opacity-90 transition-all disabled:opacity-20 disabled:cursor-not-allowed text-[10px] md:text-xs font-black uppercase tracking-[0.2em] shadow-xl shadow-primary/20">
          {currentIndex === questions.length - 1 ? "Finish" : "Next"} <ChevronRight size={18} />
        </button>
      </div>
      <p className="text-center text-xs text-muted-foreground mt-4">Keys: 1-4 answer · N next · P prev · B bookmark</p>
    </div>
  );
};

export default Practice;
