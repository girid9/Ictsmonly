import { useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { BookOpen, Swords, ArrowRight, Target, TrendingUp, Search, Flame, Zap } from "lucide-react";
import { useDataStore, useProgressStore } from "@/store/useAppStore";
import { search } from "@/services/questionBank";

const Home = () => {
  const { subjects, questionsBySubjectTopic } = useDataStore();
  const { answers, bookmarkedIds, lastVisited, streak, xp } = useProgressStore();
  const navigate = useNavigate();
  const [query, setQuery] = useState("");

  const stats = useMemo(() => {
    const total = Object.values(questionsBySubjectTopic).reduce(
      (acc, topics) => acc + Object.values(topics).reduce((a, qs) => a + qs.length, 0), 0
    );
    const answered = Object.keys(answers).length;
    const correct = Object.values(answers).filter((a) => a.correct).length;
    const accuracy = answered > 0 ? Math.round((correct / answered) * 100) : 0;
    return { total, answered, correct, accuracy, bookmarks: bookmarkedIds.length, streak, xp };
  }, [questionsBySubjectTopic, answers, bookmarkedIds, streak, xp]);

  const searchResults = useMemo(() => {
    if (!query.trim()) return [];
    return search(query);
  }, [query]);

  return (
    <div className="p-6 md:p-10 max-w-5xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-8 mb-12">
        <div>
          <p className="text-sm font-black text-primary uppercase tracking-[0.3em] mb-2">Today</p>
          <h1 className="text-4xl md:text-5xl font-black tracking-tighter text-foreground">Dashboard</h1>
        </div>
        <div className="relative w-full md:w-96">
          <Search size={20} className="absolute left-5 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input type="text" placeholder="Search everything..." value={query} onChange={(e) => setQuery(e.target.value)}
            className="w-full pl-14 pr-6 py-4.5 bg-white/40 dark:bg-white/5 border border-white/40 dark:border-white/10 rounded-[2rem] text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 transition-all font-bold shadow-sm" />
          {searchResults.length > 0 && (
            <div className="absolute top-full mt-3 left-0 right-0 glass-card p-2 shadow-2xl max-h-80 overflow-y-auto z-50">
              {searchResults.slice(0, 10).map((q) => (
                <button key={q.id} onClick={() => { navigate(`/practice/${q.subjectId}/${q.topicId}`); setQuery(""); }}
                  className="w-full text-left px-6 py-4 hover:bg-white/40 dark:hover:bg-white/5 transition-colors rounded-2xl">
                  <p className="text-sm font-black truncate">{q.question}</p>
                  <p className="text-[10px] text-muted-foreground uppercase font-black tracking-widest mt-1">{q.subjectName} • {q.topicName}</p>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 mb-12">
        <div className="glass-card p-8 relative overflow-hidden group">
          <div className="absolute -top-4 -right-4 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
            <Target size={120} />
          </div>
          <div className="flex items-center gap-3 mb-6">
            <div className="h-10 w-10 rounded-2xl bg-primary/10 flex items-center justify-center">
              <TrendingUp size={20} className="text-primary" />
            </div>
            <p className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground">Accuracy</p>
          </div>
          <div className="flex items-end gap-3">
            <span className="text-6xl font-black tracking-tighter">{stats.accuracy}%</span>
          </div>
        </div>

        <div className="glass-card p-8 relative overflow-hidden group">
          <div className="absolute -top-4 -right-4 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
            <Zap size={120} />
          </div>
          <div className="flex items-center gap-3 mb-6">
            <div className="h-10 w-10 rounded-2xl bg-blue-500/10 flex items-center justify-center">
              <Zap size={20} className="text-blue-500" />
            </div>
            <p className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground">Total XP</p>
          </div>
          <div className="flex items-end gap-3">
            <span className="text-6xl font-black tracking-tighter">{stats.xp}</span>
          </div>
        </div>

        <div className="glass-card p-8 relative overflow-hidden group">
          <div className="absolute -top-4 -right-4 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
            <BookOpen size={120} />
          </div>
          <div className="flex items-center gap-3 mb-6">
            <div className="h-10 w-10 rounded-2xl bg-green-500/10 flex items-center justify-center">
              <Target size={20} className="text-green-500" />
            </div>
            <p className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground">Answered</p>
          </div>
          <div className="flex items-end gap-3">
            <span className="text-6xl font-black tracking-tighter">{stats.answered}</span>
          </div>
        </div>
      </div>
      {lastVisited && (
        <Link to={`/practice/${lastVisited.subjectId}/${lastVisited.topicId}`}
          className="glass-card p-5 mb-8 flex items-center justify-between hover:border-primary/40 transition-all group block">
          <div>
            <p className="text-xs text-primary font-medium uppercase tracking-wider mb-1">Continue where you left off</p>
            <p className="font-semibold">{lastVisited.topicName}</p>
            <p className="text-sm text-muted-foreground">{lastVisited.subjectName}</p>
          </div>
          <ArrowRight size={20} className="text-primary group-hover:translate-x-1 transition-transform" />
        </Link>
      )}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Link to="/subjects" className="glass-card p-6 flex items-center gap-4 hover:border-primary/40 transition-all group">
          <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center"><BookOpen size={24} className="text-primary" /></div>
          <div><h3 className="font-semibold">Start Practice</h3><p className="text-sm text-muted-foreground">{subjects.length} subjects available</p></div>
          <ArrowRight size={18} className="ml-auto text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
        </Link>
        <Link to="/battle" className="glass-card p-6 flex items-center gap-4 hover:border-primary/40 transition-all group">
          <div className="h-12 w-12 rounded-xl bg-warning/10 flex items-center justify-center"><Swords size={24} className="text-warning" /></div>
          <div><h3 className="font-semibold">Battle Mode</h3><p className="text-sm text-muted-foreground">Challenge a friend</p></div>
          <ArrowRight size={18} className="ml-auto text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
        </Link>
      </div>
    </div>
  );
};

export default Home;
