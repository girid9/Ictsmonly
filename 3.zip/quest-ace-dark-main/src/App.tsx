import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { HashRouter, Routes, Route } from "react-router-dom";
import { Layout } from "@/components/Layout";
import Index from "./pages/Index";
import Subjects from "./pages/Subjects";
import Topics from "./pages/Topics";
import Practice from "./pages/Practice";
import Results from "./pages/Results";
import Bookmarks from "./pages/Bookmarks";
import WrongAnswers from "./pages/WrongAnswers";
import Battle from "./pages/Battle";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <HashRouter>
        <Routes>
          <Route element={<Layout />}>
            <Route path="/" element={<Index />} />
            <Route path="/subjects" element={<Subjects />} />
            <Route path="/subjects/:subjectId" element={<Topics />} />
            <Route path="/practice/:subjectId/:topicId" element={<Practice />} />
            <Route path="/results" element={<Results />} />
            <Route path="/bookmarks" element={<Bookmarks />} />
            <Route path="/wrong" element={<WrongAnswers />} />
            <Route path="/battle" element={<Battle />} />
          </Route>
          <Route path="*" element={<NotFound />} />
        </Routes>
      </HashRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
