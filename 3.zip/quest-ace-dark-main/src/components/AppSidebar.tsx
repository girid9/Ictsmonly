import { NavLink } from "react-router-dom";
import {
  Home,
  BookOpen,
  Bookmark,
  XCircle,
  Swords,
  X,
  Flame,
  Zap
} from "lucide-react";
import { useProgressStore } from "@/store/useAppStore";

const links = [
  { to: "/", icon: Home, label: "Home" },
  { to: "/subjects", icon: BookOpen, label: "Subjects" },
  { to: "/bookmarks", icon: Bookmark, label: "Bookmarks" },
  { to: "/wrong", icon: XCircle, label: "Wrong Answers" },
  { to: "/battle", icon: Swords, label: "Battle" },
];

interface Props {
  onClose: () => void;
}

export function AppSidebar({ onClose }: Props) {
  const { streak, xp } = useProgressStore();

  return (
    <div className="w-64 h-full bg-white/30 dark:bg-black/20 backdrop-blur-xl flex flex-col border-r border-white/20 dark:border-white/5">
      <div className="h-24 flex items-center justify-between px-8">
        <div className="flex items-center gap-3">
          <div className="h-12 w-12 rounded-2xl bg-primary shadow-lg shadow-primary/30 flex items-center justify-center">
            <span className="text-white font-black text-2xl">Q</span>
          </div>
          <span className="font-black text-xl tracking-tighter text-foreground">QUEST ACE</span>
        </div>
        <button
          onClick={onClose}
          className="md:hidden p-2 rounded-full bg-white/20 transition-colors"
        >
          <X size={20} />
        </button>
      </div>

      <div className="px-6 mb-8">
        <div className="bg-white/40 dark:bg-white/5 rounded-[2rem] p-5 space-y-5 border border-white/40 dark:border-white/5 shadow-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="h-10 w-10 rounded-2xl bg-orange-500/20 flex items-center justify-center">
                <Flame size={20} className="text-orange-500" />
              </div>
              <div>
                <p className="text-[10px] text-muted-foreground uppercase font-black tracking-widest">Streak</p>
                <p className="text-base font-black">{streak} Days</p>
              </div>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="h-10 w-10 rounded-2xl bg-blue-500/20 flex items-center justify-center">
                <Zap size={20} className="text-blue-500" />
              </div>
              <div>
                <p className="text-[10px] text-muted-foreground uppercase font-black tracking-widest">XP</p>
                <p className="text-base font-black">{xp} Points</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <nav className="flex-1 px-4 space-y-3">
        {links.map(({ to, icon: Icon, label }) => (
          <NavLink
            key={to}
            to={to}
            end={to === "/"}
            className={({ isActive }) =>
              `flex items-center gap-4 px-6 py-4 rounded-[1.5rem] text-sm font-black transition-all duration-300 ${
                isActive
                  ? "bg-white/60 dark:bg-white/10 text-primary shadow-md"
                  : "text-muted-foreground hover:bg-white/30 dark:hover:bg-white/5 hover:text-foreground"
              }`
            }
          >
            <Icon size={22} />
            {label}
          </NavLink>
        ))}
      </nav>

      <div className="p-4 border-t border-sidebar-border">
        <p className="text-[10px] text-muted-foreground text-center font-medium">
          ITI EXAM PREP v2.0
        </p>
      </div>
    </div>
  );
}
